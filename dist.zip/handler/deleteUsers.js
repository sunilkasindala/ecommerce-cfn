"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.deleteuser = void 0;
const dynamodbLib_1 = require("../utils/dynamodbLib");
const logger_1 = require("../utils/logger");
const appConfig_1 = require("../utils/appConfig");
const deleteuser = async (event) => {
    const segment = (0, logger_1.getSegment)();
    const subsegment = segment?.addNewSubsegment(`query SES template`);
    try {
        logger_1.log.info('DeleteUser request received');
        const userId = event.queryStringParameters?.userId;
        logger_1.log.info("UserId extracted from query parameters");
        if (!userId) {
            logger_1.log.warn('DeleteUser request failed - missing userId');
            return {
                statusCode: 400,
                body: JSON.stringify({ message: "Missing userId" })
            };
        }
        const params = {
            TableName: appConfig_1.AppConfig.USER_TABLE,
            Key: {
                userId
            },
            ReturnValues: "ALL_OLD"
        };
        const response = await (0, dynamodbLib_1.call)('delete', params);
        logger_1.log.info("User deleted successfully from DynamoDB");
        subsegment?.close();
        return {
            statusCode: 200,
            body: JSON.stringify({ message: "user is deleted successfully" })
        };
    }
    catch (err) {
        logger_1.log.error("Failed to delete user" + JSON.stringify(err));
        return {
            statusCode: 500,
            body: JSON.stringify({ message: "internal server error" })
        };
    }
};
exports.deleteuser = deleteuser;
