"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.signupHandler = void 0;
const client_cognito_identity_provider_1 = require("@aws-sdk/client-cognito-identity-provider");
const appConfig_1 = require("../utils/appConfig");
const logger_1 = require("../utils/logger");
const cognitoClient = new client_cognito_identity_provider_1.CognitoIdentityProviderClient({
    region: appConfig_1.AppConfig.AWS_REGION
});
const signupHandler = async (event) => {
    logger_1.log.info('signup flow is started');
    try {
        const { email, password } = event.body ? JSON.parse(event.body) : {};
        logger_1.log.info('email is executed', email);
        logger_1.log.info('password is executed', password);
        if (!email || !password) {
            return {
                statusCode: 400,
                body: JSON.stringify({
                    message: "email and password are required fields"
                })
            };
        }
        // creating user in cognito 
        const createUserParams = {
            UserPoolId: appConfig_1.AppConfig.USER_POOL_ID,
            Username: email,
            UserAttributes: [
                { Name: "email", Value: email },
                { Name: "email_verified", Value: "true" }
            ],
            MessageAction: "SUPPRESS"
        };
        const command = new client_cognito_identity_provider_1.AdminCreateUserCommand(createUserParams);
        const response = await cognitoClient.send(command); //creates users in cognito  
        logger_1.log.info('creating user is successfully created' + JSON.stringify(response));
        //creating a password in cognito 
        const setpasswordParams = {
            UserPoolId: appConfig_1.AppConfig.USER_POOL_ID,
            Username: email,
            Password: password,
            Permanent: true
        };
        const cmd = new client_cognito_identity_provider_1.AdminSetUserPasswordCommand(setpasswordParams);
        const res = await cognitoClient.send(cmd);
        logger_1.log.info('password is successfully set' + JSON.stringify(res));
        return {
            statusCode: 201,
            body: JSON.stringify({
                message: "user is registered successfully"
            })
        };
    }
    catch (err) {
        logger_1.log.info('error is getting called' + JSON.stringify(err));
        return {
            statusCode: 400,
            body: JSON.stringify({
                message: "signup failed"
            })
        };
    }
};
exports.signupHandler = signupHandler;
