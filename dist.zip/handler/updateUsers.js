"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.updateuser = void 0;
const dynamodbLib_1 = require("../utils/dynamodbLib");
const logger_1 = require("../utils/logger");
const appConfig_1 = require("../utils/appConfig");
const client_sqs_1 = require("@aws-sdk/client-sqs");
const client_sns_1 = require("@aws-sdk/client-sns");
const sqs = new client_sqs_1.SQSClient({ region: process.env.AWS_REGION });
const QUEUE_URL = process.env.NOTIFICATION_QUEUE_URL;
const sns = new client_sns_1.SNSClient({ region: process.env.AWS_REGION });
const updateuser = async (event) => {
    const segment = (0, logger_1.getSegment)();
    const subsegment = segment?.addNewSubsegment(`query SES template`);
    try {
        const body = event.body ? JSON.parse(event.body) : {};
        const { userId, name, email, mobile_no } = body;
        logger_1.log.info("parsed from body userId");
        logger_1.log.info("parsed from body name");
        logger_1.log.info("parsed from body email");
        logger_1.log.info("parsed from body mobile_no");
        const params = {
            TableName: appConfig_1.AppConfig.USER_TABLE,
            Key: { userId },
            UpdateExpression: "SET #name = :name , #email = :email",
            ExpressionAttributeNames: {
                "#name": "name",
                "#email": "email"
            },
            ExpressionAttributeValues: {
                ":name": name,
                ":email": email
            },
            ReturnValues: "ALL_NEW"
        };
        const response = await (0, dynamodbLib_1.call)('update', params);
        logger_1.log.info("user is updated successfully" + JSON.stringify(response));
        if (QUEUE_URL)
            await triggerForEmailSend(body);
        logger_1.log.info(`mobile_no is present (${mobile_no}), triggering SNS SMS`);
        if (mobile_no)
            await triggerForSmsSend(body);
        logger_1.log.info("sns message is successfully sent ");
        subsegment?.close();
        return {
            statusCode: 200,
            body: JSON.stringify({ message: "user details updated successfully" })
        };
    }
    catch (err) {
        logger_1.log.error("cannot update the user" + JSON.stringify(err));
        return {
            statusCode: 500,
            body: JSON.stringify({ message: "internal server error" })
        };
    }
};
exports.updateuser = updateuser;
const triggerForEmailSend = async (body) => {
    const message = {
        type: "USER_UPDATED",
        userId: body.userId,
        name: body.name,
        email: body.email
    };
    try {
        await sqs.send(new client_sqs_1.SendMessageCommand({
            QueueUrl: QUEUE_URL,
            MessageBody: JSON.stringify(message)
        }));
        logger_1.log.info("Notification message sent to SQS");
    }
    catch (err) {
        logger_1.log.error("Failed to send SQS message: " + JSON.stringify(err));
    }
};
const triggerForSmsSend = async (body) => {
    const params = {
        Message: `Hi ${body.name} successfully updated the user`,
        PhoneNumber: body.mobile_no
    };
    try {
        const response = await sns.send(new client_sns_1.PublishCommand(params));
        logger_1.log.info("sns publish respose" + JSON.stringify(response));
    }
    catch (err) {
        logger_1.log.error("failed to send sns message" + JSON.stringify(err));
    }
};
