"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.documentReminder = void 0;
const logger_1 = require("../utils/logger");
const appConfig_1 = require("../utils/appConfig");
const dynamodbLib_1 = require("../utils/dynamodbLib");
const client_sqs_1 = require("@aws-sdk/client-sqs");
const sqs = new client_sqs_1.SQS({});
const documentReminder = async () => {
    try {
        logger_1.log.info("Document reminder cron started");
        const result = await getUsersWithPendingDocuments();
        const users = result.Items || [];
        logger_1.log.info(`total users found ${users.length}`);
        await Promise.all(users.map((user) => triggerForEmail(user)));
    }
    catch (error) {
        logger_1.log.error("Error in document reminder cron" + JSON.stringify(error));
    }
};
exports.documentReminder = documentReminder;
const getUsersWithPendingDocuments = async () => {
    const params = {
        TableName: appConfig_1.AppConfig.USER_TABLE,
        IndexName: "documentSubmitted-userId-index",
        KeyConditionExpression: "#doc = :val",
        ExpressionAttributeNames: {
            "#doc": "documentSubmitted",
        },
        ExpressionAttributeValues: {
            ":val": "false",
        },
    };
    return await (0, dynamodbLib_1.call)("query", params);
};
const triggerForEmail = async (user) => {
    const message = {
        type: "DOCUMENT_REMINDER",
        email: user.email,
        name: user.name
    };
    try {
        await sqs.send(new client_sqs_1.SendMessageCommand({
            QueueUrl: process.env.NOTIFICATION_QUEUE_URL,
            MessageBody: JSON.stringify(message)
        }));
        logger_1.log.info(`Notification message sent to SQS for ${user.email}`);
    }
    catch (err) {
        logger_1.log.error("Failed to send SQS message:" + JSON.stringify(err));
    }
};
