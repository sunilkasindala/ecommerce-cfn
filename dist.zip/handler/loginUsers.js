"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.loginHandler = void 0;
const client_cognito_identity_provider_1 = require("@aws-sdk/client-cognito-identity-provider");
const appConfig_1 = require("../utils/appConfig");
const logger_1 = require("../utils/logger");
const jsonwebtoken_1 = __importDefault(require("jsonwebtoken"));
const dynamodbLib_1 = require("../utils/dynamodbLib");
const cognitoClient = new client_cognito_identity_provider_1.CognitoIdentityProviderClient({
    region: appConfig_1.AppConfig.AWS_REGION
});
const loginHandler = async (event) => {
    logger_1.log.info('login handler is called' + JSON.stringify(event));
    try {
        const { username, password } = event.body ? JSON.parse(event.body) : {};
        logger_1.log.info('username is expected' + JSON.stringify(username));
        logger_1.log.info('password is expected' + JSON.stringify(password));
        if (!username || !password) {
            return {
                statusCode: 400,
                body: JSON.stringify({
                    message: "username and password are required"
                })
            };
        }
        const params = {
            AuthFlow: "USER_PASSWORD_AUTH",
            ClientId: appConfig_1.AppConfig.COGNITO_CLIENT_ID,
            AuthParameters: {
                USERNAME: username,
                PASSWORD: password
            }
        };
        const command = new client_cognito_identity_provider_1.InitiateAuthCommand(params); //verify the users
        const response = await cognitoClient.send(command);
        logger_1.log.info('end' + JSON.stringify(response));
        const authResult = response.AuthenticationResult;
        logger_1.log.info('auth' + JSON.stringify(authResult));
        //extract sub id from  the token 
        logger_1.log.info('getting id token');
        const idToken = authResult?.IdToken;
        if (!idToken) {
            throw new Error('Id token missing from cognito response');
        }
        logger_1.log.info('fetched id token' + JSON.stringify(idToken));
        logger_1.log.info('extracting the id');
        const decoded = jsonwebtoken_1.default.decode(idToken);
        if (!decoded || !decoded.sub) {
            throw new Error("Unable to extract cognito sub");
        }
        const cognitoSub = decoded.sub;
        logger_1.log.info('retrived the id' + JSON.stringify(cognitoSub));
        //get user by performig db operation 
        logger_1.log.info('getting the user details by fecthing the sub id');
        const dbResult = await getUserbyCognitoSub(cognitoSub);
        logger_1.log.info("TABLE NAME => " + appConfig_1.AppConfig.USER_TABLE);
        if (!dbResult.Items || dbResult.Items.length === 0) {
            return {
                statusCode: 404,
                body: JSON.stringify({
                    message: "user not found in the db"
                })
            };
        }
        const user = dbResult.Items[0];
        logger_1.log.info('user details is retrieved successfully');
        return {
            statusCode: 200,
            body: JSON.stringify({
                message: "login succccessful",
                accessToken: authResult?.AccessToken,
                idToken: authResult?.IdToken,
                refreshToken: authResult?.RefreshToken,
                user
            })
        };
    }
    catch (err) {
        logger_1.log.error('login failed' + JSON.stringify(err));
        return {
            statusCode: 401,
            body: JSON.stringify({
                message: "invalid username and password"
            })
        };
    }
};
exports.loginHandler = loginHandler;
const getUserbyCognitoSub = async (sub) => {
    const params = {
        TableName: appConfig_1.AppConfig.USER_TABLE,
        IndexName: "cognito-index",
        KeyConditionExpression: "#cs = :cs",
        ExpressionAttributeNames: {
            "#cs": "cognitoSub"
        },
        ExpressionAttributeValues: {
            ":cs": sub
        }
    };
    return await (0, dynamodbLib_1.call)("query", params);
};
