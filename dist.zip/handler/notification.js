"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const client_ses_1 = require("@aws-sdk/client-ses");
const logger_1 = require("../utils/logger");
const EMAIL_SOURCE = "sunil.kasindala@hyniva.com";
const ses = new client_ses_1.SESClient({ region: process.env.AWS_REGION });
const handler = async (event) => {
    for (const record of event.Records) {
        try {
            const message = JSON.parse(record.body);
            const toEmail = message.email;
            switch (message.type) {
                case "USER_CREATED": {
                    logger_1.log.info({ email: message.email }, "Sending USER_CREATED email");
                    const subject = "Account Created!";
                    const body = `Hi ${message.name}, your account has been created.`;
                    const response = await SendSES(toEmail, subject, body);
                    logger_1.log.info({ messageId: response.MessageId }, "SES accepted USER_CREATED email");
                    break;
                }
                case "USER_UPDATED": {
                    logger_1.log.info({ email: message.email }, "Sending USER_UPDATED email");
                    const subject = "User Updated Successfully";
                    const body = `Hello ${message.name}, your details have been updated successfully.`;
                    const response = await SendSES(toEmail, subject, body);
                    logger_1.log.info({ messageId: response.MessageId }, "SES accepted USER_UPDATED email");
                    break;
                }
                case "DOCUMENT_REMINDER": {
                    logger_1.log.info({ email: message.email }, "sending documentSubmitted email");
                    const subject = "Users with document submitted";
                    const body = `hello ${message.name},you have not submitted your documents yet. Please submit them as soon as possible`;
                    const response = await SendSES(toEmail, subject, body);
                    logger_1.log.info({ messageId: response.MessageId }, "SES accepted document_Submitted email");
                    break;
                }
                default:
                    logger_1.log.warn({ type: message.type }, "Unknown message type received from SQS");
            }
        }
        catch (err) {
            logger_1.log.error({ err }, "Failed to process SQS message");
            throw err;
        }
    }
};
exports.handler = handler;
const SendSES = async (toEmail, subject, body) => {
    return await ses.send(new client_ses_1.SendEmailCommand({
        Source: EMAIL_SOURCE,
        Destination: {
            ToAddresses: [toEmail],
        },
        Message: {
            Subject: { Data: subject },
            Body: {
                Text: {
                    Data: body,
                },
            },
        },
    }));
};
