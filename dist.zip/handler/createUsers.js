"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createuser = void 0;
const logger_1 = require("../utils/logger");
const appConfig_1 = require("../utils/appConfig");
const client_sqs_1 = require("@aws-sdk/client-sqs");
const client_sns_1 = require("@aws-sdk/client-sns");
const crypto_1 = require("crypto");
const validations_1 = require("../utils/validations");
const validations_2 = require("../utils/validations");
const client_cognito_identity_provider_1 = require("@aws-sdk/client-cognito-identity-provider");
const cognitoClient = new client_cognito_identity_provider_1.CognitoIdentityProviderClient({
    region: appConfig_1.AppConfig.AWS_REGION
});
const dynamodbLib_1 = require("../utils/dynamodbLib");
const sqs = new client_sqs_1.SQSClient({ region: process.env.AWS_REGION });
const QUEUE_URL = process.env.NOTIFICATION_QUEUE_URL;
const sns = new client_sns_1.SNSClient({ region: process.env.AWS_REGION });
const createuser = async (event) => {
    logger_1.log.info("Create user handler called");
    try {
        const body = event.body ? JSON.parse(event.body) : {};
        const { name, email, mobile_no, password } = body;
        if (!name || !email || !mobile_no || !password) {
            return {
                statusCode: 400,
                body: JSON.stringify({
                    message: "name, email, mobile_no and password are required"
                })
            };
        }
        if (!(0, validations_2.isValidEmail)(email)) {
            return { statusCode: 400, body: JSON.stringify({ message: "Invalid email" }) };
        }
        if (!(0, validations_1.isValidMobileNumber)(mobile_no)) {
            return { statusCode: 400, body: JSON.stringify({ message: "Invalid mobile number" }) };
        }
        // Check existing user in DB
        const existingUser = await checkExistingUser(body);
        if (existingUser.Items?.length > 0) {
            return { statusCode: 400, body: JSON.stringify({ message: "Email already exists" }) };
        }
        const existingMobile = await checkExistingMobile(body);
        if (existingMobile.Items?.length > 0) {
            return { statusCode: 400, body: JSON.stringify({ message: "Mobile already exists" }) };
        }
        // creating the user in cognito
        const createUserParams = {
            UserPoolId: appConfig_1.AppConfig.USER_POOL_ID,
            Username: email,
            UserAttributes: [
                { Name: "email", Value: email },
                { Name: "email_verified", Value: "true" }
            ],
            MessageAction: "SUPPRESS"
        };
        const command = new client_cognito_identity_provider_1.AdminCreateUserCommand(createUserParams);
        const response = await cognitoClient.send(command);
        //extract sub 
        const cognitoSub = response.User?.Attributes?.find(attr => attr.Name === "sub")?.Value;
        if (!cognitoSub) {
            throw new Error("Cognito sub not found");
        }
        logger_1.log.info("Extracted cognitoSub: " + cognitoSub);
        // set the password for created user
        const setpasswordParams = {
            UserPoolId: appConfig_1.AppConfig.USER_POOL_ID,
            Username: email,
            Password: password,
            Permanent: true
        };
        const cmd = new client_cognito_identity_provider_1.AdminSetUserPasswordCommand(setpasswordParams);
        const res = await cognitoClient.send(cmd);
        const userId = (0, crypto_1.randomUUID)();
        const params = {
            TableName: appConfig_1.AppConfig.USER_TABLE,
            Item: {
                userId,
                name,
                email,
                mobile_no,
                documentSubmitted: "false",
                cognitoSub
            },
            ConditionExpression: "attribute_not_exists(userId)"
        };
        await (0, dynamodbLib_1.call)("put", params);
        if (QUEUE_URL)
            await triggerForEmailSend({ ...body, userId });
        if (mobile_no)
            await triggerForSmsSend({ ...body });
        return {
            statusCode: 201,
            body: JSON.stringify({
                message: "User created successfully"
            })
        };
    }
    catch (err) {
        logger_1.log.error("Error creating user" + JSON.stringify(err));
        return {
            statusCode: 500,
            body: JSON.stringify({ message: "Internal server error" })
        };
    }
};
exports.createuser = createuser;
const checkExistingUser = async (body) => {
    //query on database using an idex on email
    const checkEmailparams = {
        TableName: appConfig_1.AppConfig.USER_TABLE,
        IndexName: "email-index",
        KeyConditionExpression: "#email = :email",
        ExpressionAttributeNames: {
            "#email": "email"
        },
        ExpressionAttributeValues: {
            ":email": body.email
        }
    };
    //checks for email
    return await (0, dynamodbLib_1.call)('query', checkEmailparams);
};
const checkExistingMobile = async (body) => {
    const checkmobileparams = {
        TableName: appConfig_1.AppConfig.USER_TABLE,
        IndexName: "mobile-index",
        KeyConditionExpression: "#mobile_no = :mobile_no",
        ExpressionAttributeNames: {
            "#mobile_no": "mobile_no"
        },
        ExpressionAttributeValues: {
            ":mobile_no": body.mobile_no
        }
    };
    return await (0, dynamodbLib_1.call)('query', checkmobileparams);
};
const triggerForEmailSend = async (body) => {
    const message = {
        type: "USER_CREATED",
        userId: body.userId,
        name: body.name,
        email: body.email,
        mobile_no: body.mobile_no
    };
    try {
        await sqs.send(new client_sqs_1.SendMessageCommand({
            QueueUrl: QUEUE_URL,
            MessageBody: JSON.stringify(message)
        }));
        logger_1.log.info("Notification message sent to SQS");
    }
    catch (err) {
        logger_1.log.error("Failed to send SQS message: " + JSON.stringify(err));
    }
};
const triggerForSmsSend = async (body) => {
    logger_1.log.info("smsi trgger started");
    const params = {
        Message: `Hello ${body.name}, your account has been created successfully.`,
        PhoneNumber: body.mobile_no
    };
    logger_1.log.info("SNS Publish params: " + JSON.stringify(params));
    try {
        const response = await sns.send(new client_sns_1.PublishCommand(params));
        logger_1.log.info("SNS publish response: " + JSON.stringify(response));
        logger_1.log.info("sns successfully pushes the message to subscriber");
    }
    catch (err) {
        logger_1.log.error("failed to send sns message" + JSON.stringify(err));
    }
};
