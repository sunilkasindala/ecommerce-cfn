"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.scanusers = exports.getuser = void 0;
const dynamodbLib_1 = require("../utils/dynamodbLib");
const logger_1 = require("../utils/logger");
const appConfig_1 = require("../utils/appConfig");
const getuser = async (event) => {
    const segment = (0, logger_1.getSegment)();
    const subsegment = segment?.addNewSubsegment(`query SES template`);
    logger_1.log.info("EVENT RECEIVED:");
    try {
        logger_1.log.info('GetUser request received');
        const userId = event.queryStringParameters?.userId;
        logger_1.log.info("UserId extracted from query parameters");
        if (!userId) {
            logger_1.log.warn('GetUser request failed - missing userId');
            return {
                statusCode: 400,
                body: JSON.stringify({ message: "Missing userId" })
            };
        }
        const params = {
            TableName: appConfig_1.AppConfig.USER_TABLE,
            Key: {
                userId
            }
        };
        const result = await (0, dynamodbLib_1.call)('get', params);
        logger_1.log.info('User fetched successfully from DynamoDB');
        subsegment?.close();
        return {
            statusCode: 200,
            body: JSON.stringify({ message: "data is retrieved successfully", data: result.Item })
        };
    }
    catch (err) {
        logger_1.log.info("Failed to fetch user" + JSON.stringify(err));
        return {
            statusCode: 500,
            body: JSON.stringify({ message: "internal server error", err })
        };
    }
};
exports.getuser = getuser;
const scanusers = async (event) => {
    const segment = (0, logger_1.getSegment)();
    const subsegment = segment?.addNewSubsegment(`query SES template`);
    try {
        logger_1.log.info('ScanUsers request received');
        const params = {
            TableName: appConfig_1.AppConfig.USER_TABLE,
            FilterExpression: "#name = :n AND #email = :e",
            ExpressionAttributeNames: {
                "#name": "name",
                "#email": "email"
            },
            ExpressionAttributeValues: {
                ":n": "sunil",
                ":e": "sunil@gmail.com"
            }
        };
        const result = await (0, dynamodbLib_1.call)('scan', params);
        if (!result) {
            logger_1.log.warn('No users found for scan request');
            return {
                statusCode: 400,
                body: JSON.stringify({ message: 'there is no data available to fetch' })
            };
        }
        logger_1.log.info("Scan completed successfully");
        subsegment?.close();
        return {
            statusCode: 200,
            body: JSON.stringify({ message: "got the items from the dynamodb", result })
        };
    }
    catch (err) {
        logger_1.log.info("Failed to scan users" + JSON.stringify(err));
        return {
            statusCode: 500,
            body: JSON.stringify({ message: "internal server error" })
        };
    }
};
exports.scanusers = scanusers;
