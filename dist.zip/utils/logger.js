"use strict";
// const { Logger } = require('@aws-lambda-powertools/logger');
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getSegment = exports.log = void 0;
exports.setAwsRequestIdForLogger = setAwsRequestIdForLogger;
// export const logger = new Logger({
//   serviceName: 'users-service'
// });
const pino_1 = __importDefault(require("pino"));
const aws_xray_sdk_core_1 = __importDefault(require("aws-xray-sdk-core"));
const https_1 = __importDefault(require("https"));
aws_xray_sdk_core_1.default.captureHTTPsGlobal(https_1.default);
const parentLogger = (0, pino_1.default)({
    name: 'cfn-conversion',
});
exports.log = parentLogger;
/**
 * Sets the child logger so that the Lambda awsRequestId is attached to all the log statements.
 *
 * @param awsRequestId Every lambda invocation has a unique request id. This request id corresponds to that invocation.
 */
function setAwsRequestIdForLogger(event, context) {
    const AmznTraceId = event.headers === undefined ? null : event.headers["X-Amzn-Trace-Id"];
    const awsRequestId = context === undefined ? null : context.awsRequestId;
    const logSource = event.logSource == undefined ? "web" : event.logSource; //find way for get info
    const logGroupName = context === undefined ? null : context.logGroupName;
    const logStreamName = context === undefined ? null : context.logStreamName;
    const headers = event.headers;
    exports.log = parentLogger.child({ AmznTraceId, awsRequestId, logSource, logGroupName, logStreamName, headers });
}
const getSegment = () => {
    aws_xray_sdk_core_1.default.setContextMissingStrategy("LOG_ERROR");
    return {
        addNewSubsegment(name) {
            exports.log.info(`Creating segment: ${name}`);
            return {
                close() {
                    exports.log.info('subsegment closing.');
                }
            };
        }
    };
};
exports.getSegment = getSegment;
