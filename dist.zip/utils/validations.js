"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isValidEmail = exports.isValidMobileNumber = void 0;
const isValidMobileNumber = (mobile) => {
    const mobileRegex = /^(\+91)?[6-9]\d{9}$/;
    return mobileRegex.test(mobile);
};
exports.isValidMobileNumber = isValidMobileNumber;
const isValidEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
    return emailRegex.test(email);
};
exports.isValidEmail = isValidEmail;
