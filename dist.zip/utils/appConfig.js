"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppConfig = void 0;
exports.AppConfig = {
    USER_TABLE: process.env.USERS_TABLE,
    AWS_REGION: process.env.AWS_REGION,
    COGNITO_CLIENT_ID: process.env.COGNITO_CLIENT_ID,
    USER_POOL_ID: process.env.USER_POOL_ID
};
