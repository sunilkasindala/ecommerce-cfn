"use strict";
// import { AppConfig } from "./appConfig";
// import { call } from "./dynamodbLib";
// export const getNextUserId = async (): Promise<number> => {
//   const params = {
//     TableName: AppConfig.COUNTER_TABLE,
//     Key: {
//       counterName: "userId"
//     },
//     UpdateExpression: "ADD currentValue :inc",
//     ExpressionAttributeValues: {
//       ":inc": 1
//     },
//     ReturnValues: "UPDATED_NEW"
//   };
//     const result = await call("update", params);
//     if (!result.Attributes || result.Attributes.currentValue === undefined) {
//     throw new Error("Failed to get next userId from Counters table");
//   }
//   return Number(result.Attributes.currentValue);
// };
